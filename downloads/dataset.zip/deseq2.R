suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(DESeq2))
suppressPackageStartupMessages(library(ggplot2))

options(readr.show_progress=FALSE)

# Output results
output_results <- function(res, filebase) {
  res <- inner_join(
    select(res, Gene=row, pval=pvalue, adjp=padj, log2fc=log2FoldChange),
    annotation,
    by="Gene"
  )
  res <- inner_join(
    res,
    rownames_to_column(
      rename_all(
        as.data.frame(counts(dds)),
        paste0,
        " count"
      ),
      var="Gene"
    ),
    by="Gene"
  )
  res <- inner_join(
    res,
    rownames_to_column(
      rename_all(
        as.data.frame(counts(dds, normalized=TRUE)),
        paste0,
        " normalised count"
      ),
      var="Gene"
    ),
    by="Gene"
  )
  res <- arrange(res, adjp, pval, Gene)
  write_tsv(res, paste0(filebase, ".all.tsv"))
  write_tsv(filter(res, adjp < 0.05), paste0(filebase, ".sig.tsv"))
}

# Get samples
samples <- read_tsv(
  "../samples.tsv",
  col_names=c("sample", "condition"),
  col_types=cols(
    sample=col_character(),
    condition=col_factor()
  )
)
stop_for_problems(samples)

samples_deseq2 <- samples
samples_deseq2$condition <- fct_relabel(
  samples_deseq2$condition,
  ~ str_replace_all(.x, "-", "_")
)

# Get annotation
annotation <- read_tsv(
  "../annotation.txt",
  col_names=c(
    "Gene", "Chr", "Start", "End", "Strand",
    "Biotype", "Name", "Description"
  ),
  col_types=cols(
    Gene=col_character(),
    Chr=col_factor(),
    Start=col_integer(),
    End=col_integer(),
    Strand=col_integer(),
    Biotype=col_factor(),
    Name=col_character(),
    Description=col_character()
  )
)

# Get counts
counts <-tibble(
  gene=character(),
  sample=factor(samples$sample, levels=unique(samples$sample))[0],
  stranded2=integer(),
  .rows=0
)
for (sample in samples$sample) {
  tmp_counts <- read_tsv(
    str_c("../star2/", sample, "/ReadsPerGene.out.tab"),
    skip=4,
    col_names=c("gene", "unstranded", "stranded1", "stranded2"),
    col_types=cols(
      gene=col_character(),
      unstranded=col_skip(),
      stranded1=col_skip(),
      stranded2=col_integer()
    )
  )
  stop_for_problems(tmp_counts)
  tmp_counts <- add_column(
    tmp_counts,
    sample=factor(sample, levels=levels(counts$sample)),
    .before="stranded2"
  )
  counts <- bind_rows(counts, tmp_counts)
}
rm(tmp_counts)

# Aggregate counts
counts <- pivot_wider(counts, names_from=sample, values_from=stranded2)

# DESeq2
design <- formula(~ condition)
dds <- DESeqDataSetFromMatrix(
  column_to_rownames(counts, var="gene"),
  column_to_rownames(samples_deseq2, var="sample"),
  design=design
)
rm(counts)
dds <- DESeq(dds)
res1 <- results(dds, contrast=c("condition", "Nic", "Cnt"), alpha=0.05, tidy=TRUE)
res2 <- results(dds, contrast=c("condition", "Oxy", "Cnt"), alpha=0.05, tidy=TRUE)
res3 <- results(dds, contrast=c("condition", "Amp", "Cnt"), alpha=0.05, tidy=TRUE)

# Output
write_tsv(
  enframe(dds$sizeFactor),
  "size-factors.tsv",
  col_names=FALSE
)
output_results(res1, "Nic")
output_results(res2, "Oxy")
output_results(res3, "Amp")
