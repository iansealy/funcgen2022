#!/usr/bin/env bash

module purge

mkdir -p fastq

cat $1 | while read line; do
  sample=`echo "$line" | awk '{ print $1 }'`
  urls=`echo "$line" | awk '{ print $2 }'`
  md5s=`echo "$line" | awk '{ print $3 }'`
  url1=`echo "$urls" | awk -F";" '{ print $1 }'`
  url2=`echo "$urls" | awk -F";" '{ print $2 }'`
  md51=`echo "$md5s" | awk -F";" '{ print $1 }'`
  md52=`echo "$md5s" | awk -F";" '{ print $2 }'`

  wget -q --timeout 60 --tries 10  -O "fastq/$sample.1.fq.gz" "$url1"
  md5=`md5sum "fastq/$sample.1.fq.gz" | awk '{ print $1 }'`
  if [ "$md51" != "$md5" ]; then
    echo "Checksum wrong for '$url1': '$md5' not '$md51'"
    exit 1
  fi

  wget -q --timeout 60 --tries 10  -O "fastq/$sample.2.fq.gz" "$url2"
  md5=`md5sum "fastq/$sample.2.fq.gz" | awk '{ print $1 }'`
  if [ "$md52" != "$md5" ]; then
    echo "Checksum wrong for '$url2': '$md5' not '$md52'"
    exit 1
  fi
done
