#!/usr/bin/env bash

module purge
module load R/4.2.1

mkdir -p deseq2
cd deseq2
Rscript ../deseq2.R
