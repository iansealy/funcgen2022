#!/usr/bin/env bash

module purge
module load STAR/2.7.10a

line=`sed "${SGE_TASK_ID}q;d" fastq.tsv`
sample=`echo $line | awk '{ print $1 }'`
fastq1=`echo $line | awk '{ print $2 }'`
fastq2=`echo $line | awk '{ print $3 }'`
mkdir -p star2/$sample
STAR \
--runThreadN 4 \
--genomeDir ref/grcz11 \
--readFilesIn $fastq1 $fastq2 \
--readFilesCommand zcat \
--outFileNamePrefix star2/$sample/ \
--quantMode GeneCounts \
--outSAMtype BAM Unsorted SortedByCoordinate \
--sjdbFileChrStartEnd `find star1 | grep SJ.out.tab$ | sort | tr '\n' ' '`
